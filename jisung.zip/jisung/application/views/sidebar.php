	<div id="sidebar" class="span3">
		<div class="well well-small"><a id="myCart" href="<?php echo site_url('welcome/cart');?>"><img src="<?php echo base_url('assets/bootshop/themes/images/ico-cart.png');?>" alt="cart"><?php echo $this->cart->total_items();?> Pesanan Mu  </a></div>
	
		<br/>
		  
			<div class="thumbnail">
				<img src="<?php echo base_url('assets/bootshop/themes/images/byr.png');?>" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Metode Pembayaran</h5>
				</div>
			  </div>
	</div>